<script setup lang="ts">
import LeftNav from "@/components/LeftNav.vue";
</script>

<template>
  <LeftNav />
  <div class="right">
    <router-view></router-view>
  </div>
</template>

<style scoped>
.right {
  width: calc(100% - 180px);
  height: 100%;
}
</style>
