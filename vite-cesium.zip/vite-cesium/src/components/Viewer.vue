<template>
  <div ref="containerRef" id="cesiumContainer"></div>
</template>

<script setup lang="ts">
import { onMounted, markRaw } from "vue";
import { addCSS } from "@/tool/help.ts";
import { getViewer } from "@/webgis/viewer.ts";
import { global } from "@/webgis/global.ts";

addCSS("./node_modules/cesium/Build/CesiumUnminified/Widgets/widgets.css");

onMounted(() => {
  global.viewer = getViewer();
});
</script>

<style scoped>
#cesiumContainer {
  width: 100%;
  height: 100%;
}
</style>
