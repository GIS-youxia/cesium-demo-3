<template>
  <div class="downDiv">
    <div
      class="one"
      v-for="(oneName, index) in oneInfo"
      @click="handleExpendClick(oneName)"
    >
      <div class="name">{{ oneName }}</div>
      <ul class="downUl" :class="{ show: activeOne === oneName }">
        <li
          v-for="(item, index) in routeInfo[oneName]"
          :key="item.id"
          :class="{ active: activeTwo === item.name }"
          @click="handleRouteClick(item.path)"
        >
          {{ item.name }}
        </li>
      </ul>
    </div>
  </div>
</template>

<script>
import { routes } from "@/route/index.ts";
const oneInfo = [];

// RouteInfo
let routeInfo = {};

for (let i = 0; i < routes.length; i++) {
  if (routes[i].module && !oneInfo.includes(routes[i].module)) {
    oneInfo.push(routes[i].module);
  }

  if (routes[i].module) {
    if (!routeInfo[routes[i].module]) {
      routeInfo[routes[i].module] = [];
    }
    routeInfo[routes[i].module].push({
      id: i,
      path: routes[i].path,
      name: routes[i].name,
    });
  }
}

export default {
  components: {},
  data() {
    return {
      oneInfo,
      routeInfo,
      activeOne: "hello",
      activeTwo: "",
    };
  },
  mounted() {
    this.$router.push({ path: "Rotation" });
  },
  methods: {
    handleRouteClick(path) {
      if (!path) return;
      this.$router.push({ path });
      this.activeTwo = path;
    },
    handleExpendClick(oneName) {
      this.activeOne = oneName;
    },
  },
  created() {},
};
</script>
<style scoped>
.downDiv {
  width: 180px;
  height: 100%;
  padding-top: 10px;
  background: #2b2d3d;
  padding-left: 10px;
  padding-right: 10px;
  border: 1px solid #2b2d3d;
}
.one {
  margin-bottom: 10px;
  user-select: none;
  cursor: pointer;
  position: relative;
}
.name {
  color: #fff;
  font-size: 20px;
  font-weight: 700;
}

.downUl {
  height: 0;
  width: 100%;
  margin: 0;
  padding-left: 20px;
  overflow: hidden;
}

.show {
  height: 100%;
}

.downUl li {
  width: 100%;
  border-bottom: 1px solid #ebeef5;
  line-height: 40px;
  cursor: pointer;
  color: #fff;
  list-style: none;
  user-select: none;
  height: 40px;
}
.downActive {
  color: coral;
}

.active {
  color: #0f0 !important;
}
</style>
