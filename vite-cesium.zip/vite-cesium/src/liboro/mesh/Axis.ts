import * as Cesium from 'cesium';
import * as Liboro from '../index'

function getCylinderEntity(options:any) {
  options = options || {};

  const topRadius = options.topRadius !== undefined ? options.topRadius : 10000;
  const bottomRadius = options.bottomRadius !== undefined ? options.bottomRadius : 10000;
  const length = options.length !== undefined ? options.length : 20000;
  const color = options.color !== undefined ? options.color : '#ffffff';
  const heightReference = options.heightReference !== undefined ? options.heightReference : Cesium.HeightReference.CLAMP_TO_GROUND

  return new Cesium.Entity({
    name: 'cylinder',
    position: options.position,
    cylinder: {
      heightReference,
      topRadius,
      bottomRadius,
      length,
      material: new Cesium.ImageMaterialProperty({
        color: Cesium.Color.fromCssColorString(color),
        transparent: false
      })
    }
  })
}


// 获取圆柱图元
export function getCylinderPrimitive(options:any) {
  options = options || {};
  const topRadius = options.topRadius !== undefined ? options.topRadius : 200000;
  const bottomRadius = options.bottomRadius !== undefined ? options.bottomRadius : 200000;
  const length = options.length !== undefined ? options.length : 400000;
  const color = options.color !== undefined ? options.color : '#ffffff';
  const { modelMatrix } = options;

  const coneGeometry = new Cesium.CylinderGeometry({
    length,
    topRadius,
    bottomRadius,
    vertexFormat: Cesium.PerInstanceColorAppearance.VERTEX_FORMAT
  });

  const cesiumColor = Cesium.Color.fromCssColorString(color);
  const coneGeometryInstance = new Cesium.GeometryInstance({
    modelMatrix,
    geometry: coneGeometry,
    attributes: {
      color: Cesium.ColorGeometryInstanceAttribute.fromColor(cesiumColor)
    }
  });

  return new Cesium.Primitive({
    geometryInstances: coneGeometryInstance,
    appearance: new Cesium.PerInstanceColorAppearance({
      closed: true,
      translucent: false
    }),
    modelMatrix: modelMatrix,
    asynchronous: false
  });
}

/**
 * 添加地球的坐标轴
 * @param {*} viewer
 */
export function addAxisGlobe(viewer:any) {
  const width = 40000;
  const length = 6000 * 500;

  const lineX = getCylinderEntity({
    heightReference: Cesium.HeightReference.CLAMP_TO_GROUND,
    length,
    topRadius: width,
    bottomRadius: width,
    color: '#ff0000',
    position: new Cesium.Cartesian3(1, 0, 0)
  })
  viewer.entities.add(lineX)

  const lineY = getCylinderEntity({
    heightReference: Cesium.HeightReference.CLAMP_TO_GROUND,
    length,
    topRadius: width,
    bottomRadius: width,
    color: '#00ff00',
    position: new Cesium.Cartesian3(0, 1, 0)
  })
  viewer.entities.add(lineY)

  const lineZ = getCylinderEntity({
    heightReference: Cesium.HeightReference.CLAMP_TO_GROUND,
    length,
    topRadius: width,
    bottomRadius: width,
    color: '#0000ff',
    position: new Cesium.Cartesian3(0, 0, 1)
  })
  viewer.entities.add(lineZ)
}


/**
 * 绑定在对象的坐标轴
 * @export
 * @class AxisByObject
 */
export class AxisByObject {
  private _scale: number;
  private _viewer: Cesium.Viewer;
  private _linePrimitives: Array<Cesium.Primitive>;
  private  _target: Cesium.Entity | Cesium.Primitive
  private _floow: boolean;

  /**
   * Creates an instance of AxisByObject.
   * @param {*} viewer
   * @param {Cesium.Entity|Cesium.Primitive} target 目标对象
   * @memberof AxisByObject
   */
  constructor(viewer: Cesium.Viewer, target: Cesium.Entity | Cesium.Primitive, scale?:number) {
    this._scale = scale || 1;;
    this._viewer = viewer;
    this._linePrimitives = []
    this._target = target;

    this._floow = false;
    this._init()
  }

  get floow() {
    return this._floow;
  }

  /**
   * 旋转跟随目标对象
   */
  set floow(v) {
    this._floow = v;
  }

  _init() {
    const { _viewer,_scale } = this;
    const length = 200 * _scale;
    const width = 1 * _scale;

    const lineInfos: any = [
      {
        rotMatrix: Cesium.Matrix3.fromRotationY(90 * Math.PI / 180),
        translate: { x: length / 2, y: 0, z: 0 },
        color: "#ff0000",
      },
      {
        rotMatrix: Cesium.Matrix3.fromRotationX(90 * Math.PI / 180),
        translate: { x: 0, y: length / 2, z: 0 },
        color: "#00ff00",
      },
      {
        rotMatrix: Cesium.Matrix3.fromRotationZ(90 * Math.PI / 180),
        translate: { x: 0, y: 0, z: length / 2 },
        color: "#0000ff",
      },
    ]

    for (let i = 0; i < lineInfos.length; i++) {
      const lineInfo = lineInfos[i];
      const { rotMatrix, translate, color } = lineInfo;

      const modelMatrix = Cesium.Matrix4.multiply(
        Cesium.Matrix4.IDENTITY,
        Cesium.Matrix4.fromRotationTranslation(rotMatrix, new Cesium.Cartesian3(translate.x, translate.y, translate.z)),
        new Cesium.Matrix4());

      const linePrimitive = getCylinderPrimitive({
        topRadius: width,
        bottomRadius: width,
        length,
        modelMatrix,
        color
      })
      this._linePrimitives.push(linePrimitive)
      _viewer.scene.primitives.add(linePrimitive)
    }
  }

  update() {
    let modelMatrixTarget:any;
    if (this._target instanceof Cesium.Entity) {
      modelMatrixTarget = this.computeModelMatrix((this._target as any).orientation?._value, (this._target as any).position?._value);
    }

    if (this._target instanceof Cesium.Primitive) {
      modelMatrixTarget = this._target.modelMatrix;
    }

    const translate = new Cesium.Cartesian3()
    Cesium.Matrix4.getTranslation(modelMatrixTarget, translate)

    const rotation:any = new Cesium.Cartesian3(1, 0, 0)
    if (this.floow) {
      Cesium.Matrix4.getRotation(modelMatrixTarget, rotation)
    } else {
      Cesium.Matrix4.getRotation(Cesium.Matrix4.IDENTITY, rotation)
    }

    for (let i = 0; i < this._linePrimitives.length; i++) {
      const line = this._linePrimitives[i];

      Cesium.Matrix4.multiply(
        Cesium.Matrix4.IDENTITY,
        Cesium.Matrix4.fromRotationTranslation(rotation, new Cesium.Cartesian3(translate.x, translate.y, translate.z)),
        line.modelMatrix);
    }
  }

  computeModelMatrix(quaternion: any, position: any) {
    if (!quaternion) {
      quaternion = new Cesium.Quaternion()
    }
    const modelMatrix = new Cesium.Matrix4();
    const rotationMat = Cesium.Matrix3.fromQuaternion(quaternion, new Cesium.Matrix3())
    Cesium.Matrix4.fromRotationTranslation(rotationMat, position, modelMatrix)
    return modelMatrix;
  }
}
