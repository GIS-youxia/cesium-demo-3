Cesium 内容的二次封装。
