import * as Cesium from 'cesium';

export class Entity extends Cesium.Entity {
  constructor(options: Cesium.Entity.ConstructorOptions) {
    super(options);
  }

  get rotation() {
    return "123567"
  }
}
