<script setup lang="ts">
import Viewer from "@/components/Viewer.vue";
</script>

<template>
  <Viewer />
</template>

<style scoped></style>
