<script setup lang="ts">
import Viewer from "@/components/Viewer.vue";
</script>

<template>
  <!-- <Viewer /> -->
  b
</template>

<style scoped></style>
