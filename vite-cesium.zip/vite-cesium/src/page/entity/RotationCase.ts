import * as Cesium from "cesium";
import { global } from "../../webgis/global";
import { ChinaCity, setView } from "../../webgis/camera";
import * as Liboro from '../../liboro/index'
import { addClickPoint } from '../../webgis/ray';

export class RotationCase {
  constructor() {
    const viewer: Cesium.Viewer = global.viewer;

    const a = {
      longitude: 0.07142416024840811,
      latitude: -0.37900139251781545,
    }
    addClickPoint(viewer);
    Liboro.addAxisGlobe(viewer);

    // setView(viewer, {
    //   ...ChinaCity.BeiJing,
    //   height: 5000
    // })
    //定义一个box实体
    var box = new Liboro.Entity({
      name: 'BLUE  box with black outline',
      position: Cesium.Cartesian3.fromDegrees(a.longitude, a.latitude, 0.0),
      plane: {
        plane: new Cesium.Plane(Cesium.Cartesian3.UNIT_X, 0.0),
        dimensions: new Cesium.Cartesian2(9000000.0, 9000000.0), // (x,y,z)
        material: Cesium.Color.BLUE.withAlpha(0.5),//蓝色半透明
        outline: true,
        outlineColor: Cesium.Color.RED, //红色轮廓线
        // heightReference: Cesium.HeightReference.NONE
      }
    });

    const axis = new Liboro.AxisByObject(viewer, box, 500);
    axis.update();
    axis.floow = true;

    // box.position.
    (window as any).box = box;
    viewer.entities.add(box)
    viewer.zoomTo(box);
  }
}
