<script setup lang="ts">
import { onMounted } from "vue";
import Viewer from "@/components/Viewer.vue";
import { RotationCase } from "./RotationCase.ts";

onMounted(() => {
  new RotationCase();
});
</script>

<template>
  <Viewer />
</template>

<style scoped></style>
