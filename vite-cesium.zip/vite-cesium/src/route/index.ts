import { createRouter, createWebHashHistory } from "vue-router";
import { RouteItem } from './interface'

//路由数组
const routes: Array<RouteItem> = [
  {
    path: "/Hello",
    name: "Hello",
    component: import("@/page/Hello.vue"),
  },
  // camera
  {
    path: "/b",
    name: "b",
    module: "camera",
    component: import("@/page/camera/b.vue"),
  },
  // entity
  {
    path: "/Rotation",
    name: "Rotation",
    module: "entity",
    component: import("@/page/entity/Rotation.vue"),
  },
];

//路由对象
const router = createRouter({
  routes,
  history: createWebHashHistory(),
});

export { router, routes };
