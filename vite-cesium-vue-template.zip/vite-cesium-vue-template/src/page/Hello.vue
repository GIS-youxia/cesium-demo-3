<template>
  <div ref="containerRef" id="cesiumContainer"></div>
</template>

<script setup lang="ts">
import { onMounted } from "vue";
import { addCSS } from "@/tool/help.ts";
import { getViewer } from "@/webgis/viewer.ts";
import { global } from "@/webgis/global.ts";
import { Tile } from "./Tile.ts";

addCSS("./node_modules/cesium/Build/CesiumUnminified/Widgets/widgets.css");

onMounted(() => {
  global.viewer = getViewer();
  const tile = new Tile(global.viewer);
});
</script>

<style scoped>
#cesiumContainer {
  width: 100%;
  height: 100%;
}
</style>
