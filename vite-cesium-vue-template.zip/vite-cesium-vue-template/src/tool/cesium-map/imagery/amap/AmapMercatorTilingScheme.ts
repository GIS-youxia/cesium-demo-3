/**
 * @Author: Caven
 * @Date: 2021-01-31 22:07:05
 */
import * as Cesium from 'cesium';

import CoordTransform from '../../transform/CoordTransform'

class AmapMercatorTilingScheme extends Cesium.WebMercatorTilingScheme {
  constructor(options?: { ellipsoid?: Cesium.Ellipsoid | undefined; numberOfLevelZeroTilesX?: number | undefined; numberOfLevelZeroTilesY?: number | undefined; rectangleSouthwestInMeters?: Cesium.Cartesian2 | undefined; rectangleNortheastInMeters?: Cesium.Cartesian2 | undefined; } | undefined) {
    super(options)
    let projection = new Cesium.WebMercatorProjection();
    (this as any)._projection.project = function (cartographic: { longitude: number; latitude: number; }, result: number[] | Cesium.Cartesian3) {
      result = CoordTransform.WGS84ToGCJ02(
        Cesium.Math.toDegrees(cartographic.longitude),
        Cesium.Math.toDegrees(cartographic.latitude)
      )
      result = projection.project(
        new Cesium.Cartographic(
          Cesium.Math.toRadians(result[0]),
          Cesium.Math.toRadians(result[1])
        )
      )
      return new Cesium.Cartesian2(result.x, result.y)
    };

    (this as any)._projection.unproject = function(cartesian: Cesium.Cartesian3, result: number[]) {
      let cartographic = projection.unproject(cartesian)
      result = CoordTransform.GCJ02ToWGS84(
        Cesium.Math.toDegrees(cartographic.longitude),
        Cesium.Math.toDegrees(cartographic.latitude)
      )
      return new Cesium.Cartographic(
        Cesium.Math.toRadians(result[0]),
        Cesium.Math.toRadians(result[1])
      )
    }
  }
}

export default AmapMercatorTilingScheme
