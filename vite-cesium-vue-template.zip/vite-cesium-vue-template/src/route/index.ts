import { createRouter, createWebHashHistory } from "vue-router";
import { RouteItem } from './interface'

//路由数组
const routes: Array<RouteItem> = [
  {
    path: "/Hello",
    name: "Hello",
    component: import("@/page/Hello.vue"),
  },
];

//路由对象
const router = createRouter({
  routes,
  history: createWebHashHistory(),
});

export { router, routes };
