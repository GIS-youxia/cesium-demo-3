export interface RouteItem {
  path: string;
  name: string;
  module?: string;
  component: any,
}

export interface RouteInfo {
  string: Array<RouteItem>;
}

