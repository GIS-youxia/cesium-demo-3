import * as Cesium from "cesium";

class Global {
  _viewer?: Cesium.Viewer;
  _listener = new Map();

  constructor() { }

  get viewer(): Cesium.Viewer {
    return this._viewer as Cesium.Viewer;
  }

  set viewer(v: Cesium.Viewer) {
    this._viewer = v;
    if (this._listener.has("viewer")) {
      this._listener.get("viewer").forEach((callback:Function) => {
        callback(v);
      });
    }
  }

  on(type:string, callback:Function) {
    if (!this._listener.has(type)) {
      this._listener.set(type,[]);
    }
    this._listener.get(type).push(callback);
  }
}

const global = new Global();
export { global }
