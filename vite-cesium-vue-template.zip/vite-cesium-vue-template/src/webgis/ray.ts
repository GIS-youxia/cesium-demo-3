import * as Cesium from 'cesium';

export function addClickPoint(_viewer:Cesium.Viewer, cb ?:any) {
  // 注册屏幕点击事件
  let handler = new Cesium.ScreenSpaceEventHandler(_viewer.scene.canvas);

  handler.setInputAction((event:any) => {
    // 拾取椭球表面
    let clickPosition:any = _viewer.scene.camera.pickEllipsoid(event.position);

    // 转经纬度（弧度）坐标
    let radiansPos = Cesium.Cartographic.fromCartesian(clickPosition);

    // 转角度
    const lon = Cesium.Math.toDegrees(radiansPos.longitude);
    const lat = Cesium.Math.toDegrees(radiansPos.latitude);
    console.log(`{
      longitude: ${lon},
      latitude: ${lat},
    }`);

    cb && cb(clickPosition);

    // 添加点
    _viewer.entities.add({
      position: clickPosition,
      point: {
        color: Cesium.Color.YELLOW,
        pixelSize: 10
      }
    })
  }, Cesium.ScreenSpaceEventType.LEFT_CLICK);
}
