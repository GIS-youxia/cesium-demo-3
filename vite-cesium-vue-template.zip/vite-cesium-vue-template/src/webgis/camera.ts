import * as Cesium from "cesium";

const ChinaCity = {
  BeiJing: {
    longitude: 116.4715397068917,
    latitude: 39.9945712104195,
  },
  ShenZhen: {
    longitude: 114.05643562967782,
    latitude: 22.54490159071341,
  },
};
export { ChinaCity };

interface SetViewOptions {
  longitude: number;
  latitude: number;
  height?: number;
  heading?: number;
  pitch?: number;
  roll?: number;
}

export function setView(viewer: Cesium.Viewer, options: SetViewOptions) {
  const position = Cesium.Cartesian3.fromDegrees(
    options.longitude,
    options.latitude,
    options.height||0
  );

  viewer.camera.setView({
    destination: position,
    orientation: {
      // 水平旋转
      heading: Cesium.Math.toRadians(options.heading || 0),
      // 垂直旋转
      pitch: Cesium.Math.toRadians(options.pitch || -45),
      roll: Cesium.Math.toRadians(options.roll || 0),
    },
  });
}
